To run this code 

1. g++ -std=c++14 chords.cpp
2. ./a.out

The input format is

In the first line type n, where 2*n is the size of the circle
In the second line type 2*n space separated integers, the weights of the nodes (1 based indexing)

Output format
n lines denoting the chords
ai bi denotes a chord connecting ai to bi (1 based indexing)
The next line has the total weight of all the chords

The README.md in the Stress folder has the details on how this code was tested.